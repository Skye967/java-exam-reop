package com.JavaExam.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.JavaExam.models.Task;
import com.JavaExam.models.User;
import com.JavaExam.services.ExamService;

@Controller
public class TaskController {
	private final ExamService examService;

	public TaskController(ExamService examService) {
		this.examService = examService;
	}
	
	@RequestMapping("/create/task")
	public String createTask(@ModelAttribute("newTask") Task task, Model model, HttpSession session) {
		model.addAttribute("ThisUser", session.getAttribute("currentUser"));
		model.addAttribute("assigneeList", examService.findAllUsers());
		return "newTask.jsp";
	}
	
	@RequestMapping(value="/new/task", method=RequestMethod.POST)
	public String newTask(@Valid @ModelAttribute("newTask") Task task, BindingResult result, Model model, HttpSession session) {
		long taskCount = task.getWork().getTasks().size();
		System.out.println("taskCount");
		model.addAttribute("ThisUser", session.getAttribute("currentUser"));
		model.addAttribute("assigneeList", examService.findAllUsers());	
		
		if(result.hasErrors()) {
			return "newTask.jsp";
		}
		examService.createNewTask(task);
		return "redirect:/home";
	}
	
	@RequestMapping("/display/{taskId}")
	public String displayTask(@PathVariable("taskId") long taskId, Model model, HttpSession session) {
		model.addAttribute("thisTask", examService.getTaskbyId(taskId));
		model.addAttribute("thisUser", session.getAttribute("currentUser"));
		System.out.println(examService.getTaskbyId(taskId));
		return "displayTask.jsp";
	}
	
	
	@RequestMapping("/delete/{taskId}")
	public String deleteTask(@PathVariable("taskId") long taskId) {
		examService.deleteEventbyId(taskId);
		return "redirect:/home";
	}
	
	@RequestMapping("/edit/{taskId}")
	public String editTask(@PathVariable("taskId") long taskId, Model model, @ModelAttribute("newTask") Task task, HttpSession session) {
		Task thisTask = examService.getTaskbyId(taskId);
		model.addAttribute("editTask", thisTask);
		model.addAttribute("assigneeList", examService.findAllUsers());
		model.addAttribute("thisUser", session.getAttribute("currentUser"));
		User user = (User) session.getAttribute("currentUser");
		if(user.getId() != thisTask.getUser().getId()) {
			return "redirect:/home";
		}
		return "edit.jsp";
	}
	
	
}








