package com.JavaExam.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import javax.validation.Valid;

import com.JavaExam.models.Task;
import com.JavaExam.models.User;
import com.JavaExam.services.ExamService;
import com.JavaExam.validator.UserValidator;

//imports removed for brevity
@Controller
public class UserController {
private final ExamService examService;
private final UserValidator userValidator;
 
 public UserController(ExamService examService, UserValidator userValidator) {
     this.examService = examService;
     this.userValidator = userValidator;
 }
 
 @RequestMapping("/")
 public String index(@ModelAttribute("user") User user) {
	 return "index.jsp";
 }
 
 
 @RequestMapping(value="/registration", method=RequestMethod.POST)
 public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
	 userValidator.validate(user, result);
	 if(result.hasErrors()) {
		 return "index.jsp";
	 }else {
		 examService.registerUser(user);
		 if(session.getAttribute("currentUser") == null) {
			 session.setAttribute("currentUser", user);
			 return "redirect:/home";
		 }
	 }
// if result has errors, return the registration page (don't worry about validations just now)
 // else, save the user in the database, save the user id in session, and redirect them to the /home route
	 return null;
 }
 
 @RequestMapping(value="/login", method=RequestMethod.POST)
 public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session, RedirectAttributes flashMessages) {
	 if(examService.authenticateUser(email, password)) {
		 User loginUser = examService.findByEmail(email);
		 session.setAttribute("currentUser", loginUser);
		 return "redirect:/home";
	 } else {
		 String errors = "Incorrect Login or Password";
		 flashMessages.addFlashAttribute("error", errors);
		 return "redirect:/";
	 }
     // if the user is authenticated, save their user id in session
     // else, add error messages and return the login page
 }
 
 @RequestMapping("/home")
 public String home(HttpSession session, Model model, @ModelAttribute("newTask") Task task) {
	 model.addAttribute(session.getAttribute("currentUser"));
	 model.addAttribute("ThisUser", session.getAttribute("currentUser"));
	 model.addAttribute("assigneeList", examService.findAllUsers());
	 model.addAttribute("taskList", examService.getAllTasks());
	 return "home.jsp";
 }
 @RequestMapping("/logout")
 public String logout(HttpSession session) {
	 session.invalidate();
     // invalidate session
     // redirect to login page
	 return "redirect:/";
 }
}
