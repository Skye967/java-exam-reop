package com.JavaExam.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.JavaExam.models.Task;

public interface TaskRepo extends CrudRepository<Task, Long>{
	List<Task> findAll();
	Task findById(long id);

}
